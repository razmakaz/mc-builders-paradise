1. Copy creeper.properties from this folder
2. Go to assets\minecraft\optifine\cem
3. Paste and replace creeper.properties